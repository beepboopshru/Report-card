// Session 7 - Grade 6: Rain response
// Arduino UNO
#include <Servo.h>

const byte RAIN=2,SERVO_PIN=3,BUZZER=5;
Servo cover;

void setup() {
  pinMode(RAIN,INPUT);
  pinMode(BUZZER,OUTPUT);
  cover.attach(SERVO_PIN);
  cover.write(0);
}

void loop() {
  bool wet=digitalRead(RAIN)==LOW;
  cover.write(wet?90:0);
  delay(200);
}
